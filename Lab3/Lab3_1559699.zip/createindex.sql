-- Eduardo Chavez (echavez9@ucsc.edu)
-- createindex.sql

CREATE INDEX LookUpReturns ON TaxReturns(kind, dateFiled);

