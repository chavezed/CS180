-- Eduardo Chavez (echavez9@ucsc.edu)
-- unittests.sql


INSERT INTO IRSagents(IRSagentID, taxpayerID, jobLevel, active)
    VALUES (BB3312, 310, 2, TRUE);

INSERT INTO Delinquents(taxpayerID, IRSagentID, collectionAgencyID)
    VALUES (103, XX1163, 546);

INSERT INTO Delinquents(taxpayerID, IRSagentID, collectionAgencyID)
    VALUES (444, YY6666, 999);

UPDATE Payments
    SET amountPaid = 2000.0
    WHERE datePaid > DATE '01/01/2017';

UPDATE Payments
    SET amountPaid = -333.3
    WHERE datePaid > DATE '01/01/2017';

UPDATE Businesses
    SET lastDatePaid = DATE '01/01/1999'
    WHERE lastDateFiled > DATE '01/01/2015';

UPDATE Businesses
    SET lastDatePaid = DATE '01/01/2030'
    WHERE lastDateFiled > DATE '01/01/2015';

UPDATE IRSagents
    SET jobLevel = 3, active = NULL
    WHERE jobLevel > 0;

UPDATE IRSagents
    SET jobLevel = NULL, active = TRUE
    WHERE jobLevel > 2;

UPDATE Individuals
    SET taxpayerID = 756
    WHERE name LIKE 'Jin%';

UPDATE Individuals
    SET taxpayerID = spouseID
    WHERE name LIKE 'Leslie%';
