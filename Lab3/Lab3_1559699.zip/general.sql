-- Eduardo Chavez (echavez9@ucsc.edu)
-- general.sql

ALTER TABLE Payments ADD CONSTRAINT positive_payments
    CHECK (amountPaid > 0);

ALTER TABLE Businesses ADD CONSTRAINT date_filed_greater
    CHECK (lastDateFiled >= lastDatePaid);

ALTER TABLE IRSagents ADD CONSTRAINT jobLevel_not_null
    CHECK (jobLevel IS NOT NULL OR active IS NULL);

ALTER TABLE Individuals ADD CONSTRAINT taxp_ne_spouse
    CHECK (taxpayerID <> spouseID);
