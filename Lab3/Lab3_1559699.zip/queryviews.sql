-- Eduardo Chavez (echavez9@ucsc.edu)
-- queryviews.sql


SELECT d.taxpayerID, td.debt, pc.credit
FROM Delinquents d, TaxDebts td, PaymentCredits pc
WHERE d.taxpayerID = td.taxpayerID
    AND d.taxpayerID = pc.taxpayerID;


/* 
DELETE FROM TaxReturns
WHERE taxpayerID = 112
    AND taxYear = 2016;

DELETE FROM TaxReturns
WHERE taxpayerID = 116
    AND taxYear = 2017;

Before deleting:

 taxpayerid |   debt    |  credit   
------------+-----------+-----------
        112 | 112765.00 | 122878.93
(1 row)

After deleting:

     taxpayerid | debt | credit 
------------+------+--------
(0 rows)



/*
