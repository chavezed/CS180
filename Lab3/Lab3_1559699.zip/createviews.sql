-- Eduardo Chavez (echavez9@ucsc.edu)
-- createviews.sql

CREATE VIEW TaxDebts AS
    SELECT taxpayerID, SUM(taxOwed) AS debt
    FROM TaxReturns
    GROUP BY taxpayerID
    HAVING COUNT(*) >= 4;

CREATE VIEW PaymentCredits AS
    SELECT taxpayerID, MAX(datePaid) AS biggestDatePaid, SUM(amountPaid) AS credit
    FROM Payments
    GROUP BY taxpayerID
    HAVING COUNT(DISTINCT amountPaid) >= 2;

SELECT *
FROM TaxDebts;

SELECT *
FROM PaymentCredits;
